#!/system/bin/sh
MODDIR=${0%/*}
STATE_DIR=/data/adb/sound_universal
mkdir -p "$STATE_DIR" 2>/dev/null
chmod 0700 "$STATE_DIR" 2>/dev/null
# Wait briefly for Android's boot-complete property; module mounts are already
# established before late_start, but this avoids racing early service startup.
COUNT=0
while [ "$(getprop sys.boot_completed 2>/dev/null)" != "1" ] && [ "$COUNT" -lt 30 ]; do
  sleep 2
  COUNT=$((COUNT + 1))
done
"$MODDIR/tools/sync_settings.sh" "$MODDIR" >/dev/null 2>&1
"$MODDIR/tools/boot_audio_check.sh" "$MODDIR" >/dev/null 2>&1
STATUS="$MODDIR/integration.status"
MODE=$(sed -n 's/^mode=//p' "$STATUS" 2>/dev/null | head -n 1)
echo "[$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null)] Sound universal v0.5.1 boot check; integration=${MODE:-unknown}." >> "$STATE_DIR/service.log" 2>/dev/null
exit 0
