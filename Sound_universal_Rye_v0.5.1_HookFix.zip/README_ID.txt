Sound universal v0.5.1 — catatan integrasi hook

APA YANG DIPERBAIKI
- Installer membedakan XML/library yang baru disiapkan dari konfigurasi yang benar-benar terlihat setelah boot.
- service.sh menjalankan pemeriksaan setelah overlay module dimuat, lalu memperbarui integration.status.
- Action memeriksa UUID di konfigurasi aktif, keberadaan library native untuk ABI perangkat, dan mencari signature runtime di AudioFlinger.
- WebUI menampilkan status menunggu reboot, konfigurasi aktif, overlay tidak aktif, atau konfigurasi aktif tetapi library hilang.

PENTING
Magisk/KernelSU/APatch memasang file systemless overlay melalui siklus boot. Audio Effects XML biasanya dibaca ketika layanan audio dimulai. Karena itu modul ini menyiapkan hook saat instalasi dan memverifikasinya setelah reboot; tidak memaksa restart audioserver selama pemasangan karena dapat memutus atau merusak audio.

STATUS ACTION
- RUNTIME_VERIFIED: ada konfigurasi/library aktif dan signature efek terlihat pada dump AudioFlinger.
- CONFIG_ACTIVE_RUNTIME_UNCONFIRMED: konfigurasi UUID dan library aktif terlihat, tetapi runtime DSP belum terbukti. Putar musik lalu tekan Action lagi.
- WAITING_FOR_BOOT_OR_OVERLAY: menunggu boot atau overlay belum terlihat.
- NOT_VERIFIED: pemeriksaan tidak mempunyai bukti yang cukup.

KETERBATASAN
Build ini berisi native legacy AudioEffect library ARM/AArch64. Installer sengaja tidak memalsukan dukungan AIDL Audio Effects HAL; ROM yang hanya menggunakan jalur AIDL memerlukan implementasi AIDL yang benar-benar kompatibel. Keberadaan XML/library saja bukan bukti bahwa audio berubah pada semua ROM/vendor.

Setelan DSP disimpan di /data/adb/sound_universal/settings.json dan disinkronkan ke /data/misc/audio/sound_universal.conf. Tes suara dilakukan saat playback aktif dan setelah menerapkan preset Music focus.
