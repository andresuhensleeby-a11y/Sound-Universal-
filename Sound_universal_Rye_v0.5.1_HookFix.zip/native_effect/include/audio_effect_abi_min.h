#ifndef SOUND_UNIVERSAL_AUDIO_EFFECT_ABI_MIN_H
#define SOUND_UNIVERSAL_AUDIO_EFFECT_ABI_MIN_H
/* Minimal ABI declarations based on the Android Open Source Project hardware/audio_effect.h.
 * Apache-2.0 compatible definitions; no proprietary/vendor code is included. */
typedef unsigned char su_u8;
typedef unsigned short su_u16;
typedef unsigned int su_u32;
typedef signed short su_i16;
typedef signed int su_i32;
typedef unsigned long su_size;
typedef _Bool su_bool;
#define SU_NULL ((void*)0)
#define SU_EFFECT_CONTROL_API_VERSION ((2u << 16) | 0u)
#define SU_EFFECT_LIBRARY_API_VERSION ((3u << 16) | 0u)
#define SU_AUDIO_EFFECT_LIBRARY_TAG 0x41454c54u /* 'AELT' */

typedef struct su_effect_uuid {
    su_u32 timeLow;
    su_u16 timeMid;
    su_u16 timeHiAndVersion;
    su_u16 clockSeq;
    su_u8 node[6];
} su_effect_uuid_t;

typedef struct su_effect_descriptor {
    su_effect_uuid_t type;
    su_effect_uuid_t uuid;
    su_u32 apiVersion;
    su_u32 flags;
    su_u16 cpuLoad;
    su_u16 memoryUsage;
    char name[64];
    char implementor[64];
} su_effect_descriptor_t;

struct su_effect_interface;
typedef struct su_effect_interface **su_effect_handle_t;
typedef struct su_audio_buffer {
    su_size frameCount;
    union { void *raw; su_i32 *s32; su_i16 *s16; su_u8 *u8; };
} su_audio_buffer_t;
typedef su_i32 (*su_buffer_function_t)(void *, su_audio_buffer_t *);
typedef struct su_buffer_provider {
    su_buffer_function_t getBuffer;
    su_buffer_function_t releaseBuffer;
    void *cookie;
} su_buffer_provider_t;
typedef struct su_buffer_config {
    su_audio_buffer_t buffer;
    su_u32 samplingRate;
    su_u32 channels;
    su_buffer_provider_t bufferProvider;
    su_u8 format;
    su_u8 accessMode;
    su_u16 mask;
} su_buffer_config_t;
typedef struct su_effect_config {
    su_buffer_config_t inputCfg;
    su_buffer_config_t outputCfg;
} su_effect_config_t;

struct su_effect_interface {
    su_i32 (*process)(su_effect_handle_t self, su_audio_buffer_t *inBuffer, su_audio_buffer_t *outBuffer);
    su_i32 (*command)(su_effect_handle_t self, su_u32 cmdCode, su_u32 cmdSize,
                      void *pCmdData, su_u32 *replySize, void *pReplyData);
    su_i32 (*get_descriptor)(su_effect_handle_t self, su_effect_descriptor_t *pDescriptor);
    su_i32 (*process_reverse)(su_effect_handle_t self, su_audio_buffer_t *inBuffer, su_audio_buffer_t *outBuffer);
};

typedef struct su_audio_effect_library {
    su_u32 tag;
    su_u32 version;
    const char *name;
    const char *implementor;
    su_i32 (*create_effect)(const su_effect_uuid_t *uuid, su_i32 sessionId, su_i32 ioId,
                            su_effect_handle_t *pHandle);
    su_i32 (*release_effect)(su_effect_handle_t handle);
    su_i32 (*get_descriptor)(const su_effect_uuid_t *uuid, su_effect_descriptor_t *pDescriptor);
} su_audio_effect_library_t;

#endif
