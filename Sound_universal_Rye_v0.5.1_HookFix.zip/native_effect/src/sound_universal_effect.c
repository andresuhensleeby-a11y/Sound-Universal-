#include "audio_effect_abi_min.h"

/* Shared settings are read by a background watcher, never from the real-time callback.
 * /data/misc/audio is the Android audio-data area; install/save scripts restore its label. */
extern int open(const char *path, int flags, ...);
extern long read(int fd, void *buffer, unsigned long count);
extern int close(int fd);
extern int pthread_create(long *thread, const void *attr, void *(*start)(void *), void *arg);
extern int pthread_detach(long thread);
extern int usleep(unsigned int usec);
#ifndef SU_CONFIG_PATH
#define SU_CONFIG_PATH "/data/misc/audio/sound_universal.conf"
#endif
extern float sinf(float);
extern float cosf(float);
extern float powf(float, float);
extern float sqrtf(float);
extern float expf(float);
extern float tanhf(float);

#define SU_EINVAL 22
#define SU_ENODEV 19
#define SU_ENOENT 2
#define SU_ENOMEM 12
#define SU_ENODATA 61
#define SU_ENOSYS 38
#define SU_FMT_PCM_16 1u
#define SU_FMT_PCM_FLOAT 5u
#define SU_CMD_INIT 0u
#define SU_CMD_SET_CONFIG 1u
#define SU_CMD_RESET 2u
#define SU_CMD_ENABLE 3u
#define SU_CMD_DISABLE 4u
#define SU_CMD_SET_PARAM 5u
#define SU_CMD_SET_PARAM_DEFERRED 6u
#define SU_CMD_SET_PARAM_COMMIT 7u
#define SU_CMD_GET_PARAM 8u
#define SU_CMD_SET_DEVICE 9u
#define SU_CMD_SET_VOLUME 10u
#define SU_CMD_SET_AUDIO_MODE 11u
#define SU_CMD_SET_CONFIG_REVERSE 12u
#define SU_CMD_SET_INPUT_DEVICE 13u
#define SU_CMD_GET_CONFIG 14u
#define SU_CMD_GET_CONFIG_REVERSE 15u
#define SU_CMD_GET_FEATURE_SUPPORTED_CONFIGS 16u
#define SU_CMD_GET_FEATURE_CONFIG 17u
#define SU_CMD_SET_FEATURE_CONFIG 18u
#define SU_CMD_SET_AUDIO_SOURCE 19u
#define SU_CMD_OFFLOAD 20u

#define SU_PI 3.14159265358979323846f
#define SU_MAX_INSTANCES 12
#define SU_MAX_CHANNELS 8
#define SU_BANDS 10
#define SU_FLAG_POSTPROC 4u
#define SU_FLAG_INSERT_FIRST (1u << 5)
#define SU_FLAG_INPUT_DIRECT (1u << 8)
#define SU_FLAG_OUTPUT_DIRECT (1u << 9)

static const float kFreqs[SU_BANDS] = {31.f, 62.f, 125.f, 250.f, 500.f, 1000.f, 2000.f, 4000.f, 8000.f, 16000.f};
static const su_effect_uuid_t kTypeUuid = {0x7e3522c1u, 0x9347u, 0x4c81u, 0xa23au, {0x1a,0x23,0x3a,0x22,0x00,0x00}};
static const su_effect_uuid_t kImplUuid = {0x7e3522c1u, 0x9347u, 0x4c81u, 0xa23au, {0x1a,0x23,0x3a,0x22,0x00,0x01}};

static void bytes_copy(void *dst, const void *src, su_size n) {
    su_u8 *d=(su_u8*)dst; const su_u8 *s=(const su_u8*)src; su_size i;
    for (i=0;i<n;i++) d[i]=s[i];
}
static void bytes_zero(void *dst, su_size n) { su_u8 *d=(su_u8*)dst; su_size i; for(i=0;i<n;i++) d[i]=0; }
static int str_equal(const char *a, const char *b) { su_size i=0; if(!a||!b)return 0; while(a[i]&&b[i]&&a[i]==b[i])i++; return a[i]==b[i]; }
static float clampf(float v,float lo,float hi){return v<lo?lo:(v>hi?hi:v);}
static float absf_local(float v){return v<0.f?-v:v;}
static float db_to_gain(float db){return powf(10.f, db/20.f);}
static float parse_float(const char *s, float fallback) {
    int sign=1, seen=0, frac=0; float v=0.f, scale=0.1f;
    if(!s||!*s)return fallback;
    if(*s=='-'){sign=-1;s++;}else if(*s=='+')s++;
    while(*s){if(*s>='0'&&*s<='9'){seen=1;if(frac){v+=(float)(*s-'0')*scale;scale*=0.1f;}else v=v*10.f+(float)(*s-'0');}
        else if(*s=='.'&&!frac)frac=1;else break;s++;}
    return seen?(float)sign*v:fallback;
}
#define SU_CFG_FIELDS 16u
#define CFG_ENABLED 0u
#define CFG_PREAMP 1u
#define CFG_BASS 2u
#define CFG_CLARITY 3u
#define CFG_WIDTH 4u
#define CFG_COMPRESSION 5u
#define CFG_EQ0 6u

typedef struct {
    su_u32 enabled;
    float preamp, bass, clarity, width, compression;
    float eq[SU_BANDS];
} SettingsSnapshot;

/* Bitwise atomics allow the watcher to publish updates without locks on the audio thread. */
static volatile su_u32 g_configSeq = 0;
static volatile su_u32 g_configBits[SU_CFG_FIELDS] = {0};
static volatile su_u32 g_watcherStarted = 0;

static su_u32 float_bits(float value) { union { float f; su_u32 u; } v; v.f=value; return v.u; }
static float bits_float(su_u32 value) { union { float f; su_u32 u; } v; v.u=value; return v.f; }
static int parse_config_value(const char *text, const char *key, char *out, su_size cap) {
    const char *line=text; su_size keyLen=0; while(key[keyLen])keyLen++;
    if(!cap)return 0; out[0]=0;
    while(line && *line) {
        const char *end=line, *eq, *v, *vEnd; su_size len, n=0;
        while(*end && *end!='\n' && *end!='\r')end++;
        eq=line; while(eq<end && *eq!='=')eq++;
        if(eq<end && (su_size)(eq-line)==keyLen) {
            su_size j=0; while(j<keyLen && line[j]==key[j])j++;
            if(j==keyLen) {
                v=eq+1; while(v<end && (*v==' '||*v=='\t'))v++;
                vEnd=end; while(vEnd>v && (vEnd[-1]==' '||vEnd[-1]=='\t'))vEnd--;
                len=(su_size)(vEnd-v); while(n<len && n+1<cap){out[n]=v[n];n++;} out[n]=0; return 1;
            }
        }
        line=*end?end+1:end;
    }
    return 0;
}
static int parse_config_bool(const char *s) { return s && (s[0]=='1'||str_equal(s,"true")||str_equal(s,"on")); }
static void read_settings_file(SettingsSnapshot *v) {
    char buf[2048], tmp[48]; long n; int fd; su_u32 i;
    bytes_zero(v,sizeof(*v));
    fd=open(SU_CONFIG_PATH,0);
    if(fd<0)return;
    n=read(fd,buf,sizeof(buf)-1u); close(fd);
    if(n<=0)return; if((su_size)n>=sizeof(buf))n=(long)sizeof(buf)-1; buf[n]=0;
    if(parse_config_value(buf,"enabled",tmp,sizeof(tmp)))v->enabled=(su_u32)parse_config_bool(tmp);
    if(parse_config_value(buf,"preamp_db",tmp,sizeof(tmp)))v->preamp=clampf(parse_float(tmp,0.f),-12.f,0.f);
    if(parse_config_value(buf,"bass_db",tmp,sizeof(tmp)))v->bass=clampf(parse_float(tmp,0.f),0.f,6.f);
    if(parse_config_value(buf,"clarity_db",tmp,sizeof(tmp)))v->clarity=clampf(parse_float(tmp,0.f),0.f,3.f);
    if(parse_config_value(buf,"width",tmp,sizeof(tmp)))v->width=clampf(parse_float(tmp,0.f),0.f,100.f)/100.f;
    if(parse_config_value(buf,"compression",tmp,sizeof(tmp)))v->compression=clampf(parse_float(tmp,0.f),0.f,100.f)/100.f;
    for(i=0;i<SU_BANDS;i++){char key[8]="eq0";key[2]=(char)('0'+i);if(parse_config_value(buf,key,tmp,sizeof(tmp)))v->eq[i]=clampf(parse_float(tmp,0.f),-6.f,6.f);}
}
static void snapshot_to_bits(const SettingsSnapshot *v, su_u32 *bits) {
    su_u32 i; bits[CFG_ENABLED]=v->enabled; bits[CFG_PREAMP]=float_bits(v->preamp); bits[CFG_BASS]=float_bits(v->bass);
    bits[CFG_CLARITY]=float_bits(v->clarity); bits[CFG_WIDTH]=float_bits(v->width); bits[CFG_COMPRESSION]=float_bits(v->compression);
    for(i=0;i<SU_BANDS;i++)bits[CFG_EQ0+i]=float_bits(v->eq[i]);
}
static void publish_settings(const SettingsSnapshot *v) {
    su_u32 bits[SU_CFG_FIELDS],old[SU_CFG_FIELDS],i,seq; snapshot_to_bits(v,bits);
    for(i=0;i<SU_CFG_FIELDS;i++)old[i]=__atomic_load_n(&g_configBits[i],__ATOMIC_RELAXED);
    for(i=0;i<SU_CFG_FIELDS;i++)if(bits[i]!=old[i])break;
    if(i==SU_CFG_FIELDS)return;
    seq=__atomic_load_n(&g_configSeq,__ATOMIC_RELAXED); if(seq&1u)seq++;
    __atomic_store_n(&g_configSeq,seq+1u,__ATOMIC_SEQ_CST);
    __atomic_thread_fence(__ATOMIC_SEQ_CST);
    for(i=0;i<SU_CFG_FIELDS;i++)__atomic_store_n(&g_configBits[i],bits[i],__ATOMIC_RELAXED);
    __atomic_store_n(&g_configSeq,seq+2u,__ATOMIC_RELEASE);
}
static void *settings_watcher(void *unused) {
    (void)unused;
    for(;;){SettingsSnapshot v;read_settings_file(&v);publish_settings(&v);usleep(250000u);}
    return SU_NULL;
}
static void ensure_settings_watcher(void) {
    long thread=0;
    /* Legacy effects factory creates instances serially on Android; one watcher per library. */
    if(g_watcherStarted)return;
    g_watcherStarted=1u;
    if(pthread_create(&thread,SU_NULL,settings_watcher,SU_NULL)!=0){g_watcherStarted=0u;return;}
    (void)pthread_detach(thread);
}

typedef struct { float b0,b1,b2,a1,a2,z1,z2; } Biquad;
typedef struct {
    const struct su_effect_interface *itfe; /* must be first: effect_handle_t points here */
    su_u32 magic;
    volatile su_u32 in_use;
    su_bool apiEnabled;
    su_bool settingsEnabled;
    su_bool supported;
    su_u32 sampleRate;
    su_u32 channels;
    su_u8 format;
    float preampDb,bassDb,clarityDb,width,compression;
    float eqDb[SU_BANDS];
    su_u32 seenConfigSeq;
    float envelope;
    Biquad eq[SU_MAX_CHANNELS][SU_BANDS];
    Biquad bass[SU_MAX_CHANNELS];
    Biquad clarity[SU_MAX_CHANNELS];
} EffectContext;

static EffectContext g_instances[SU_MAX_INSTANCES];

static Biquad peak_coeff(float sr,float freq,float gainDb,float q){
    Biquad f; float ny,safe,w,c,s,A,alpha,a0; bytes_zero(&f,sizeof(f));
    ny=sr*0.45f; safe=clampf(freq,20.f,ny); w=2.f*SU_PI*safe/sr; c=cosf(w); s=sinf(w);
    A=powf(10.f,clampf(gainDb,-12.f,12.f)/40.f); alpha=s/(2.f*q); a0=1.f+alpha/A;
    f.b0=(1.f+alpha*A)/a0; f.b1=(-2.f*c)/a0; f.b2=(1.f-alpha*A)/a0; f.a1=(-2.f*c)/a0; f.a2=(1.f-alpha/A)/a0; return f;
}
static Biquad shelf_coeff(float sr,float freq,float gainDb){
    Biquad f; float A,w,c,s,alpha,beta,a0; bytes_zero(&f,sizeof(f));
    A=powf(10.f,clampf(gainDb,-6.f,6.f)/40.f); w=2.f*SU_PI*clampf(freq,20.f,sr*0.35f)/sr; c=cosf(w); s=sinf(w);
    alpha=s*0.70710678118f; beta=2.f*sqrtf(A)*alpha;
    a0=(A+1.f)+(A-1.f)*c+beta;
    f.b0=A*((A+1.f)-(A-1.f)*c+beta)/a0;
    f.b1=2.f*A*((A-1.f)-(A+1.f)*c)/a0;
    f.b2=A*((A+1.f)-(A-1.f)*c-beta)/a0;
    f.a1=-2.f*((A-1.f)+(A+1.f)*c)/a0;
    f.a2=((A+1.f)+(A-1.f)*c-beta)/a0; (void)s; return f;
}
static float biquad_run(Biquad *f,float x){float y=f->b0*x+f->z1;f->z1=f->b1*x-f->a1*y+f->z2;f->z2=f->b2*x-f->a2*y;return y;}
static void reset_states(EffectContext *c){su_u32 ch,b; c->envelope=0.f;for(ch=0;ch<SU_MAX_CHANNELS;ch++){c->bass[ch].z1=c->bass[ch].z2=0.f;c->clarity[ch].z1=c->clarity[ch].z2=0.f;for(b=0;b<SU_BANDS;b++)c->eq[ch][b].z1=c->eq[ch][b].z2=0.f;}}
static void build_filters(EffectContext *c){su_u32 ch,b;for(ch=0;ch<c->channels&&ch<SU_MAX_CHANNELS;ch++){Biquad bass=shelf_coeff((float)c->sampleRate,95.f,c->bassDb);Biquad clarity=peak_coeff((float)c->sampleRate,3200.f,c->clarityDb,.8f);c->bass[ch].b0=bass.b0;c->bass[ch].b1=bass.b1;c->bass[ch].b2=bass.b2;c->bass[ch].a1=bass.a1;c->bass[ch].a2=bass.a2;c->clarity[ch].b0=clarity.b0;c->clarity[ch].b1=clarity.b1;c->clarity[ch].b2=clarity.b2;c->clarity[ch].a1=clarity.a1;c->clarity[ch].a2=clarity.a2;
    for(b=0;b<SU_BANDS;b++){Biquad f=peak_coeff((float)c->sampleRate,kFreqs[b],c->eqDb[b],1.f);c->eq[ch][b].b0=f.b0;c->eq[ch][b].b1=f.b1;c->eq[ch][b].b2=f.b2;c->eq[ch][b].a1=f.a1;c->eq[ch][b].a2=f.a2;}}}
static void refresh_settings(EffectContext *c){
    su_u32 tries;
    for(tries=0;tries<3u;tries++){
        su_u32 before=__atomic_load_n(&g_configSeq,__ATOMIC_ACQUIRE), after, i, bits[SU_CFG_FIELDS];
        if((before&1u)||before==0u||before==c->seenConfigSeq)return;
        for(i=0;i<SU_CFG_FIELDS;i++)bits[i]=__atomic_load_n(&g_configBits[i],__ATOMIC_RELAXED);
        after=__atomic_load_n(&g_configSeq,__ATOMIC_ACQUIRE);
        if(before!=after||(after&1u))continue;
        c->settingsEnabled=(su_bool)(bits[CFG_ENABLED]!=0u);
        c->preampDb=clampf(bits_float(bits[CFG_PREAMP]),-12.f,0.f);
        c->bassDb=clampf(bits_float(bits[CFG_BASS]),0.f,6.f);
        c->clarityDb=clampf(bits_float(bits[CFG_CLARITY]),0.f,3.f);
        c->width=clampf(bits_float(bits[CFG_WIDTH]),0.f,1.f);
        c->compression=clampf(bits_float(bits[CFG_COMPRESSION]),0.f,1.f);
        for(i=0;i<SU_BANDS;i++)c->eqDb[i]=clampf(bits_float(bits[CFG_EQ0+i]),-6.f,6.f);
        c->seenConfigSeq=after;
        if(c->supported&&c->sampleRate>=8000u&&c->channels>0u&&c->channels<=SU_MAX_CHANNELS)build_filters(c);
        return;
    }
}
static int uuid_equal(const su_effect_uuid_t *a,const su_effect_uuid_t *b){su_size i;if(!a||!b)return 0;if(a->timeLow!=b->timeLow||a->timeMid!=b->timeMid||a->timeHiAndVersion!=b->timeHiAndVersion||a->clockSeq!=b->clockSeq)return 0;for(i=0;i<6;i++)if(a->node[i]!=b->node[i])return 0;return 1;}
static void descriptor_fill(su_effect_descriptor_t *d){su_size i; bytes_zero(d,sizeof(*d));d->type=kTypeUuid;d->uuid=kImplUuid;d->apiVersion=SU_EFFECT_CONTROL_API_VERSION;d->flags=SU_FLAG_POSTPROC|SU_FLAG_INSERT_FIRST|SU_FLAG_INPUT_DIRECT|SU_FLAG_OUTPUT_DIRECT;d->cpuLoad=8;d->memoryUsage=8;{const char *n="Sound universal DSP";const char *m="Rye (open DSP engine)";for(i=0;i<63&&n[i];i++)d->name[i]=n[i];for(i=0;i<63&&m[i];i++)d->implementor[i]=m[i];}}
static EffectContext *ctx_from(su_effect_handle_t h){EffectContext *c=(EffectContext*)h;if(!c||c->magic!=0x53554e49u)return SU_NULL;return c;}
static su_u32 sample_bytes(su_u8 format){switch(format){case 1:return 2u;case 2:return 1u;case 3:case 4:case 5:return 4u;case 6:return 3u;default:return 0u;}}
static void passthrough(EffectContext *c, void *ip, void *op, su_size frames){
    su_u32 bytes=sample_bytes(c->format); if(!ip||!op||ip==op||!bytes||!c->channels||c->channels>SU_MAX_CHANNELS)return;
    bytes_copy(op,ip,frames*(su_size)c->channels*(su_size)bytes);
}
static int settings_are_identity(const EffectContext *c){su_u32 i;if(absf_local(c->preampDb)>0.001f||c->bassDb>0.001f||c->clarityDb>0.001f||c->width>0.001f||c->compression>0.001f)return 0;for(i=0;i<SU_BANDS;i++)if(absf_local(c->eqDb[i])>0.001f)return 0;return 1;}
static su_i32 process_effect(su_effect_handle_t self,su_audio_buffer_t *in,su_audio_buffer_t *out){
    EffectContext *c=ctx_from(self); su_size f,frames; su_u32 ch,b; float preamp,attack,release,threshold=.78f,ratio; void *ip,*op; int hasOutput;
    if(!c)return -SU_EINVAL; if(!in)in=&(su_audio_buffer_t){0};if(!out)out=&(su_audio_buffer_t){0};
    ip=in->raw;op=out->raw;hasOutput=(op!=SU_NULL);if(!ip)ip=SU_NULL;if(!op)op=ip;if(!ip||!op)return in->frameCount==0?0:-SU_EINVAL;
    frames=in->frameCount;if(hasOutput&&out->frameCount<frames)frames=out->frameCount;
    refresh_settings(c);
    if(frames==0)return 0;
    if(!c->apiEnabled||!c->settingsEnabled||!c->supported||(c->format!=SU_FMT_PCM_16&&c->format!=SU_FMT_PCM_FLOAT)||c->channels<1||c->channels>SU_MAX_CHANNELS||settings_are_identity(c)){passthrough(c,ip,op,frames);return 0;}
    preamp=db_to_gain(c->preampDb); attack=expf(-1.f/(.010f*(float)c->sampleRate));release=expf(-1.f/(.120f*(float)c->sampleRate));ratio=1.f+3.f*c->compression;
    for(f=0;f<frames;f++){
        float values[SU_MAX_CHANNELS];float peak=0.f,compGain=1.f,left=0.f,right=0.f;
        for(ch=0;ch<c->channels;ch++){float x;if(c->format==SU_FMT_PCM_FLOAT)x=((float*)ip)[f*c->channels+ch];else x=(float)((su_i16*)ip)[f*c->channels+ch]/32768.f;if(x!=x||x>3.4e37f||x< -3.4e37f)x=0.f;values[ch]=x;if(absf_local(x)>peak)peak=absf_local(x);}
        {float coeff=peak>c->envelope?attack:release;c->envelope=coeff*c->envelope+(1.f-coeff)*peak;}
        if(c->compression>.001f&&c->envelope>threshold){float compressed=threshold+(c->envelope-threshold)/ratio;compGain=compressed/(c->envelope>.000001f?c->envelope:.000001f);}
        if(c->channels==2&&c->width>.001f){left=values[0];right=values[1];{float mid=.5f*(left+right),side=.5f*(left-right)*(1.f+.5f*c->width);values[0]=mid+side;values[1]=mid-side;}}
        for(ch=0;ch<c->channels;ch++){
            float x=values[ch];x=biquad_run(&c->bass[ch],x);for(b=0;b<SU_BANDS;b++)x=biquad_run(&c->eq[ch][b],x);x=biquad_run(&c->clarity[ch],x);x*=preamp*compGain;
            /* Soft peak limiter: only invokes tanh for over-hot peaks; no hard digital clip. */
            if(x>0.85f)x=0.85f+0.15f*tanhf((x-0.85f)*5.f);
            else if(x< -0.85f)x=-0.85f-0.15f*tanhf((-x-0.85f)*5.f);
            if(c->format==SU_FMT_PCM_FLOAT)((float*)op)[f*c->channels+ch]=x;
            else{float q=x*32767.f;if(q>32767.f)q=32767.f;if(q< -32768.f)q=-32768.f;((su_i16*)op)[f*c->channels+ch]=(su_i16)q;}
        }
    }
    return 0;
}
static su_i32 command_effect(su_effect_handle_t self,su_u32 cmd,su_u32 cmdSize,void *cmdData,su_u32 *replySize,void *replyData){
    EffectContext *c=ctx_from(self);su_i32 status=0;if(!c)return -SU_EINVAL;
    switch(cmd){
      case SU_CMD_INIT: c->apiEnabled=0;reset_states(c);break;
      case SU_CMD_SET_CONFIG:{su_effect_config_t *cfg=(su_effect_config_t*)cmdData;su_u32 sr,mask,fmt,chans=0; if(!cfg||cmdSize<sizeof(su_effect_config_t)){status=-SU_EINVAL;break;}sr=cfg->inputCfg.samplingRate;mask=cfg->inputCfg.channels;fmt=cfg->inputCfg.format;while(mask){chans+=(mask&1u);mask>>=1;}if(chans==0){mask=cfg->outputCfg.channels;while(mask){chans+=(mask&1u);mask>>=1;}}c->sampleRate=sr;c->channels=chans;c->format=(su_u8)fmt;c->supported=(su_bool)(sr>=8000u&&sr<=384000u&&chans>0u&&chans<=SU_MAX_CHANNELS&&(fmt==SU_FMT_PCM_16||fmt==SU_FMT_PCM_FLOAT));if(c->supported){build_filters(c);reset_states(c);}refresh_settings(c);break;}
      case SU_CMD_RESET: reset_states(c);break;
      case SU_CMD_ENABLE: c->apiEnabled=1;ensure_settings_watcher();refresh_settings(c);break;
      case SU_CMD_DISABLE: c->apiEnabled=0;break;
      case SU_CMD_SET_PARAM: case SU_CMD_SET_PARAM_DEFERRED: case SU_CMD_SET_PARAM_COMMIT: case SU_CMD_GET_PARAM: status=-SU_ENOSYS;break;
      case SU_CMD_SET_DEVICE: case SU_CMD_SET_VOLUME: case SU_CMD_SET_AUDIO_MODE: case SU_CMD_SET_CONFIG_REVERSE: case SU_CMD_SET_INPUT_DEVICE: case SU_CMD_SET_AUDIO_SOURCE: case SU_CMD_OFFLOAD: status=0;break;
      case SU_CMD_GET_CONFIG: case SU_CMD_GET_CONFIG_REVERSE: status=-SU_ENOSYS;break;
      default: status=-SU_ENOSYS;break;
    }
    if(replySize&&replyData&&*replySize>=sizeof(su_i32)){*(su_i32*)replyData=status;*replySize=sizeof(su_i32);}else if(replySize)*replySize=0;
    return 0;
}
static su_i32 get_descriptor_instance(su_effect_handle_t self,su_effect_descriptor_t *d){EffectContext *c=ctx_from(self);if(!c||!d)return -SU_EINVAL;descriptor_fill(d);return 0;}
static su_i32 process_reverse(su_effect_handle_t self,su_audio_buffer_t *in,su_audio_buffer_t *out){(void)self;(void)in;(void)out;return -SU_ENOSYS;}
static const struct su_effect_interface kInterface={process_effect,command_effect,get_descriptor_instance,process_reverse};

static su_i32 lib_create(const su_effect_uuid_t *uuid,su_i32 sessionId,su_i32 ioId,su_effect_handle_t *out){su_u32 i;(void)sessionId;(void)ioId;if(!uuid||!out)return -SU_EINVAL;if(!uuid_equal(uuid,&kImplUuid))return -SU_ENOENT;ensure_settings_watcher();for(i=0;i<SU_MAX_INSTANCES;i++){if(g_instances[i].in_use==0u){EffectContext *c=&g_instances[i];bytes_zero(c,sizeof(*c));c->itfe=&kInterface;c->in_use=1u;c->magic=0x53554e49u;c->preampDb=0.f;c->settingsEnabled=0;c->apiEnabled=0;c->seenConfigSeq=0u;*out=(su_effect_handle_t)&c->itfe;return 0;}}return -SU_ENOMEM;}
static su_i32 lib_release(su_effect_handle_t handle){EffectContext *c=ctx_from(handle);if(!c)return -SU_EINVAL;c->magic=0u;c->in_use=0u;return 0;}
static su_i32 lib_descriptor(const su_effect_uuid_t *uuid,su_effect_descriptor_t *d){if(!uuid||!d)return -SU_EINVAL;if(!uuid_equal(uuid,&kImplUuid))return -SU_ENOENT;descriptor_fill(d);return 0;}

__attribute__((visibility("default"))) su_audio_effect_library_t AELI={SU_AUDIO_EFFECT_LIBRARY_TAG,SU_EFFECT_LIBRARY_API_VERSION,"Sound universal DSP","Rye",lib_create,lib_release,lib_descriptor};
