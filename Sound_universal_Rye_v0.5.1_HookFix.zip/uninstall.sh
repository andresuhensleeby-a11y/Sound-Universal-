#!/system/bin/sh
# Remove only this module's private state and its shared audio setting file.
rm -rf /data/adb/sound_universal 2>/dev/null
rm -f /data/misc/audio/sound_universal.conf /data/misc/audio/sound_universal.conf.tmp 2>/dev/null
exit 0
