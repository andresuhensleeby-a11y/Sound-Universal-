#!/system/bin/sh
SKIPUNZIP=0
ui_print "********************************************"
ui_print " Sound universal 🎧 v0.5.1"
ui_print " Creator: Rye | Credit: ryetechnologia"
ui_print "********************************************"
[ -n "$MODPATH" ] || abort "Install this ZIP from your root manager's Modules section."
ui_print "Features included:"
ui_print " - 10-band EQ (31 Hz - 16 kHz)"
ui_print " - Music / Studio / Cinema / Vocal / Gaming / Night / Bass presets"
ui_print " - Smart Bass, Vocal Clarity, stereo width"
ui_print " - Dynamic compression and soft peak limiter"
ui_print " - Liquid-glass WebUI with Furina background"
ui_print " - Save, import, and export JSON settings"
ui_print " - Native audio effect for compatible legacy/HIDL audio paths"
ui_print "Checking Android / CPU ABI and available audio effects..."
[ -z "$API" ] || ui_print "Android API level: $API"
[ -z "$ARCH" ] || ui_print "Detected installer architecture: $ARCH"
for f in service.sh action.sh uninstall.sh post-fs-data.sh tools/su_status.sh tools/sync_settings.sh tools/install_audio_hook.sh tools/patch_audio_effects.awk tools/boot_audio_check.sh verify_audio.sh; do
  [ ! -f "$MODPATH/$f" ] || chmod 0755 "$MODPATH/$f" 2>/dev/null
done
[ ! -f "$MODPATH/config/default.json" ] || chmod 0644 "$MODPATH/config/default.json"
[ ! -f "$MODPATH/config/presets.json" ] || chmod 0644 "$MODPATH/config/presets.json"
[ ! -f "$MODPATH/native_effect/build/libsounduniversal.so" ] || chmod 0644 "$MODPATH/native_effect/build/libsounduniversal.so"
[ ! -f "$MODPATH/native_effect/build/libsounduniversal_arm.so" ] || chmod 0644 "$MODPATH/native_effect/build/libsounduniversal_arm.so"
"$MODPATH/tools/sync_settings.sh" "$MODPATH" >/dev/null 2>&1
"$MODPATH/tools/install_audio_hook.sh" "$MODPATH"
MODE=$(sed -n 's/^mode=//p' "$MODPATH/integration.status" 2>/dev/null | head -n 1)
ui_print "Audio integration result: ${MODE:-unknown}"
if [ "${MODE:-unknown}" = "webui_only" ]; then
  REASON=$(sed -n 's/^reason=//p' "$MODPATH/integration.status" 2>/dev/null | head -n 1)
  ui_print "DSP audio hook not installed: ${REASON:-unsupported HAL/XML}"
elif [ "${MODE:-unknown}" = "legacy_xml_staged" ]; then
  ui_print "Legacy audio XML and library overlay staged."
  ui_print "One reboot is required; service.sh will verify the active overlay after boot."
fi
ui_print "NOTE: Android 14+ often uses AIDL effects; this build does not ship an AIDL effect service."
ui_print "After reboot, open WebUI; boot-time check will distinguish active config from runtime DSP proof."
ui_print "Universal chip/ROM support cannot be guaranteed without device/HAL testing."
ui_print "********************************************"
