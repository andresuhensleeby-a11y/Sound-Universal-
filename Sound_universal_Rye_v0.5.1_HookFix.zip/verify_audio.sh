#!/system/bin/sh
# Verifies the active configuration and reports runtime evidence separately.
# It does not restart audioserver or modify protected system partitions.
MODDIR="${1:-$(CDPATH= cd -- "$(dirname -- "$0")" 2>/dev/null && pwd)}"
MODID="${MODDIR##*/}"
STATE_DIR="/data/adb/${MODID}"
STATUS_FILE="$STATE_DIR/audio_verify_status.txt"
LOG_FILE="$STATE_DIR/audio_verify.log"
UUID='7e3522c1-9347-4c81-a23a-1a233a220001'
mkdir -p "$STATE_DIR" 2>/dev/null
chmod 0700 "$STATE_DIR" 2>/dev/null
umask 077
TMP_OUT="$STATE_DIR/audio_verify.tmp.$$"
: > "$TMP_OUT" 2>/dev/null || TMP_OUT="/data/local/tmp/audio_verify.tmp.$$"
: > "$TMP_OUT" 2>/dev/null || { echo '[Audio Verify] ERROR: cannot create temporary report.'; exit 1; }
say() { echo "$*" >> "$TMP_OUT"; }
say '=== AUDIO ENGINE VERIFICATION ==='
say "Module: $MODID"
say "Android: $(getprop ro.build.version.release 2>/dev/null) (SDK $(getprop ro.build.version.sdk 2>/dev/null))"
say ''

MODULE_OK=1
BOOT_OK=0
AUDIO_OK=0
CONFIG_OK=0
LIB_OK=0
RUNTIME_OK=0
BOOT_DONE=$(getprop sys.boot_completed 2>/dev/null)
INTEGRATION_MODE=$(sed -n 's/^mode=//p' "$MODDIR/integration.status" 2>/dev/null | head -n 1)
if [ -e "$MODDIR/disable" ] || [ -e "$MODDIR/remove" ]; then
  MODULE_OK=0
  say '[GAGAL] Modul mempunyai file disable/remove.'
else
  say '[OK] Tidak ada file disable/remove pada direktori modul.'
fi
if [ "$BOOT_DONE" = '1' ]; then
  BOOT_OK=1
  say '[OK] Android selesai booting.'
else
  say "[PERINGATAN] Android belum selesai booting (sys.boot_completed=$BOOT_DONE)."
fi
say "Mode integrasi: ${INTEGRATION_MODE:-unknown}"

ACTIVE_CONFIG=''
for p in /vendor/etc/audio_effects.xml /odm/etc/audio_effects.xml /system_ext/etc/audio_effects.xml /system/etc/audio_effects.xml; do
  if [ -r "$p" ] && grep -q "$UUID" "$p" 2>/dev/null; then ACTIVE_CONFIG="$p"; break; fi
done
if [ -n "$ACTIVE_CONFIG" ]; then
  CONFIG_OK=1
  say "[OK] UUID efek terlihat pada konfigurasi aktif: $ACTIVE_CONFIG"
else
  say '[PERINGATAN] UUID efek tidak terlihat pada konfigurasi audio aktif.'
  case "$INTEGRATION_MODE" in
    legacy_xml_staged) say '[INFO] Overlay baru disiapkan. Reboot diperlukan agar Android me-mount overlay dan membaca ulang konfigurasi.' ;;
    legacy_xml_overlay_not_active) say '[PERINGATAN] Pemeriksaan boot sebelumnya juga tidak menemukan overlay pada konfigurasi aktif.' ;;
    webui_only) say '[INFO] Mode WEBUI ONLY: modul tidak memasang hook legacy pada HAL ini.' ;;
  esac
fi

ABI_LIST="$(getprop ro.product.cpu.abilist 2>/dev/null)"
ABI="$(getprop ro.product.cpu.abi 2>/dev/null)"
ACTIVE_LIB=''
case " $ABI_LIST $ABI " in
  *arm64-v8a*)
    for p in /vendor/lib64/soundfx/libsounduniversal.so /odm/lib64/soundfx/libsounduniversal.so /system_ext/lib64/soundfx/libsounduniversal.so /system/lib64/soundfx/libsounduniversal.so; do
      if [ -s "$p" ]; then ACTIVE_LIB="$p"; break; fi
    done
    ;;
esac
if [ -z "$ACTIVE_LIB" ]; then
  case " $ABI_LIST $ABI " in
    *armeabi-v7a*|*armeabi*)
      for p in /vendor/lib/soundfx/libsounduniversal.so /odm/lib/soundfx/libsounduniversal.so /system_ext/lib/soundfx/libsounduniversal.so /system/lib/soundfx/libsounduniversal.so; do
        if [ -s "$p" ]; then ACTIVE_LIB="$p"; break; fi
      done
      ;;
  esac
fi
if [ -n "$ACTIVE_LIB" ]; then
  LIB_OK=1
  say "[OK] Library native terlihat di jalur aktif: $ACTIVE_LIB"
else
  say '[PERINGATAN] Library native tidak ditemukan pada jalur audio-effect standar untuk ABI perangkat.'
fi

AUDIO_DUMP=$(dumpsys media.audio_flinger 2>/dev/null)
if [ -n "$AUDIO_DUMP" ] && ! echo "$AUDIO_DUMP" | grep -qiE 'permission denied|can.t find service|not found'; then
  AUDIO_OK=1
  say '[OK] AudioFlinger merespons dumpsys.'
else
  say '[PERINGATAN] AudioFlinger tidak dapat diperiksa melalui dumpsys.'
fi
if [ "$AUDIO_OK" = '1' ] && echo "$AUDIO_DUMP" | grep -qiE 'Sound universal DSP|sound_universal|7e3522c1-9347-4c81-a23a-1a233a220001'; then
  RUNTIME_OK=1
  say '[OK] Ditemukan signature Sound universal pada dump AudioFlinger; ini bukti runtime yang lebih kuat.'
else
  say '[PERINGATAN] Dump AudioFlinger belum menunjukkan instance Sound universal. Putar musik dulu lalu jalankan Action lagi; ketiadaan signature tidak selalu berarti gagal.'
fi

if [ "$MODULE_OK" = '1' ] && [ "$BOOT_OK" = '1' ] && [ "$CONFIG_OK" = '1' ] && [ "$LIB_OK" = '1' ] && [ "$RUNTIME_OK" = '1' ]; then
  RESULT='RUNTIME_VERIFIED'
  say ''
  say 'HASIL: RUNTIME TERDETEKSI'
elif [ "$MODULE_OK" = '1' ] && [ "$BOOT_OK" = '1' ] && [ "$CONFIG_OK" = '1' ] && [ "$LIB_OK" = '1' ]; then
  RESULT='CONFIG_ACTIVE_RUNTIME_UNCONFIRMED'
  say ''
  say 'HASIL: KONFIGURASI AKTIF, PEMROSESAN RUNTIME BELUM TERKONFIRMASI'
elif [ "$INTEGRATION_MODE" = 'legacy_xml_staged' ] || [ "$BOOT_OK" = '0' ]; then
  RESULT='WAITING_FOR_BOOT_OR_OVERLAY'
  say ''
  say 'HASIL: MENUNGGU BOOT/OVERLAY AKTIF'
else
  RESULT='NOT_VERIFIED'
  say ''
  say 'HASIL: BELUM DIVERIFIKASI'
fi

{
  echo "STATUS=$RESULT"
  echo "MODULE_ID=$MODID"
  echo "CHECKED_AT=$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null)"
  echo "ANDROID_RELEASE=$(getprop ro.build.version.release 2>/dev/null)"
  echo "SDK=$(getprop ro.build.version.sdk 2>/dev/null)"
  echo "INTEGRATION_MODE=${INTEGRATION_MODE:-unknown}"
  echo "ACTIVE_CONFIG=${ACTIVE_CONFIG:-none}"
  echo "ACTIVE_LIBRARY=${ACTIVE_LIB:-none}"
} > "$STATUS_FILE" 2>/dev/null
cat "$TMP_OUT" | tee "$LOG_FILE"
echo ''
echo "Status tersimpan: $STATUS_FILE"
rm -f "$TMP_OUT"
case "$RESULT" in RUNTIME_VERIFIED|CONFIG_ACTIVE_RUNTIME_UNCONFIRMED) exit 0;; *) exit 1;; esac
