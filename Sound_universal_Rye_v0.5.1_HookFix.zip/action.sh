#!/system/bin/sh
# Drop-in Action entry point for Magisk / KernelSU / APatch modules.
# Keep this file in the module root and make it executable.
MODDIR="$(CDPATH= cd -- "$(dirname -- "$0")" 2>/dev/null && pwd)"
if [ -z "$MODDIR" ] || [ ! -d "$MODDIR" ]; then
  echo "[Audio Verify] ERROR: cannot determine module directory."
  exit 1
fi
VERIFY="$MODDIR/verify_audio.sh"
if [ ! -f "$VERIFY" ]; then
  echo "[Audio Verify] ERROR: verify_audio.sh is missing."
  exit 1
fi
chmod 0755 "$VERIFY" 2>/dev/null
exec /system/bin/sh "$VERIFY" "$MODDIR"
