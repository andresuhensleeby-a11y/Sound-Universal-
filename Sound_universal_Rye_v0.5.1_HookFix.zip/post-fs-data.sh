#!/system/bin/sh
MODDIR=${0%/*}
# Only synchronize settings in the early boot stage. Audio-hook status is
# checked in service.sh after module mounts are visible.
"$MODDIR/tools/sync_settings.sh" "$MODDIR" >/dev/null 2>&1
exit 0
