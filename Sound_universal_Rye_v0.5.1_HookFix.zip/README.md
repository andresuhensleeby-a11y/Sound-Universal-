# Sound universal 🎧 v0.5.1

**Creator:** Rye  
**Credit:** ryetechnologia

Sound universal is a native audio DSP module with a liquid-glass WebUI and a Furina-inspired blue background. This release fixes configuration migration, adds practical JSON import/export paths, and uses a non-neutral Music focus default so an installed configuration can be tested for audible changes.

## Features actually included

- 10-band EQ (31 Hz–16 kHz, ±6 dB)
- Music focus, Balanced, Studio reference, Cinematic stage, Vocal focus, Gaming detail, Night, and Bass presets
- Smart Bass low shelf (up to +6 dB)
- Vocal clarity / presence EQ (up to +3 dB)
- Stereo stage width for stereo audio
- Dynamic compression and soft peak limiting
- Liquid-glass WebUI with a local Furina-style illustration
- Auto-save and key=value configuration sync for the native engine
- Export JSON to `/sdcard/Download/Sound-universal-settings.json`, browser-download fallback, and JSON text fallback
- Import JSON by selecting a file or pasting its content
- Installer feature list and an integration status explanation

This is an **audio module**, not a CPU/GPU, RAM, thermal, kernel, or network optimizer. It does not include proprietary Dolby or DTS components.

## Important compatibility limits

The bundled native DSP binaries target ARM/AArch64 (the common Snapdragon/MediaTek architectures). x86/x86-64 devices are reported as `WEBUI ONLY`. The DSP binary is a legacy Android AudioEffect library. Integration currently attempts compatible legacy/HIDL `audio_effects.xml` configurations. A successful systemless XML overlay only means the configuration was staged; it does **not** prove the ROM accepted or is using the effect. Audio may still bypass framework effects via vendor processing, direct/offload playback, Bluetooth paths, or other HAL choices.

Android 14 and later commonly use the AIDL Audio Effects HAL. This build deliberately reports `WEBUI ONLY` instead of pretending to support an AIDL effect service that is not included. Therefore Android 10–17, every ROM, and every chipset cannot be promised as working from ZIP-level checks alone. Snapdragon and MediaTek are not directly targeted by the DSP math, but actual audio-HAL compatibility is what determines whether sound changes.

References: [AOSP HIDL Audio HAL](https://source.android.com/docs/core/audio/hidl-implement), [AOSP AIDL Audio HAL](https://source.android.com/docs/core/audio/aidl-implement), [AIDL/HIDL comparison](https://source.android.com/docs/core/audio/aidl-hidl-comp).

## Install and test

1. Install the ZIP from the supported root manager's Modules section. The installer prints the included feature list and the detected integration mode.
2. Reboot.
3. Open the module WebUI. The status must not say `WEBUI ONLY` if you expect native DSP processing.
4. Keep Music focus selected, enable the DSP switch, press **Simpan sekarang**, and play a normal music stream. Restart playback after saving.
5. For a clear A/B test, compare Music focus against Balanced at the same volume. Balanced is intentionally neutral.

If the WebUI reports a save failure, open it from a root manager that exposes a compatible `exec` API. JSON remains visible in the backup panel even when WebView download APIs are blocked. The config is saved privately under `/data/adb/sound_universal/settings.json`; the key=value file read by the native watcher is `/data/misc/audio/sound_universal.conf`.

## Backup and restore

- **Ekspor ke Download** tries to write `/sdcard/Download/Sound-universal-settings.json` and also attempts a browser download. The JSON textarea is a fallback if either download route is blocked.
- **Impor berkas** accepts a `.json` file.
- **Tempel JSON** opens a text area for manual import.
- Import/export only handles this module's audio settings; it does not back up system partitions.

## Recovery

If sound breaks, disable the module in the root manager and reboot. If the integration status is `WEBUI ONLY`, changing sliders will update only the saved configuration, not the output audio. Do not force-patch a different HAL or copy another vendor's proprietary effect library into this module.

## Build/testing note

The ZIP can be structurally and statically checked, but this package has not been tested on a physical Android device in this build session. Real playback, SELinux labelling, the root manager WebUI API, and vendor HAL loading need device-level verification.
