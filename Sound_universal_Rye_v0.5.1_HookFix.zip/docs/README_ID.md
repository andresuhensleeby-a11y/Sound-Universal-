# Sound universal v0.5.1 — catatan Indonesia

Fitur modul ini adalah DSP audio: 10-band EQ, Music/Studio/Cinema/Vocal/Gaming/Night/Bass preset, Smart Bass, Vocal Clarity, lebar stereo, kompresi, soft peak limiter, backup JSON dan WebUI liquid glass dengan latar Furina-style.

Credit: ryetechnologia. Creator engine awal: Rye.

**Batas penting:** integrasi native yang dibundel hanya mencoba audio effect legacy/HIDL. Bila status `WEBUI ONLY`, setelan UI/JSON tidak mengubah suara. Android 14+ sering memakai AIDL; paket ini belum menyertakan implementasi AIDL factory/service. Tidak ada klaim semua ROM/chipset pasti kompatibel tanpa pengujian perangkat.

## Perbaikan hook v0.5.1
Installer menyiapkan overlay XML/library dan melaporkan `legacy_xml_staged`. Sesudah reboot, `service.sh` memeriksa konfigurasi aktif serta library sesuai ABI. Action membedakan konfigurasi aktif dari bukti runtime AudioFlinger. Ini tidak memaksa restart audioserver dan tidak menjamin semua ROM/HAL kompatibel.
