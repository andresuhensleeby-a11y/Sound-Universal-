# Native DSP audit — v0.5.1

## Implemented in this build
- Legacy AudioEffect ABI 2.0 plugin, library API 3.0, export `AELI`.
- Unique implementation/type UUID; postprocess hook for music/ring/alarm/notification only.
- 10 peaking bands, 95 Hz low shelf, 3.2 kHz vocal-presence peak, mid/side width on stereo, envelope compressor and soft peak limiter.
- PCM16 and float processing, supported rates 8–384 kHz; other known PCM formats are passed through untouched.
- Global config watcher reads the audio-data file off the real-time thread and publishes the settings via an atomic sequence. Filter coefficients refresh in the process callback only when the version changes.
- ABI builds cross-compiled for AArch64 and ARMv7; `readelf` shows expected libc/libm imports and exported `AELI`.
- Installer stages matching ABI library overlays under vendor/system/system_ext soundfx paths to accommodate ROM layouts.
- XML injector test verifies the effect is inserted inside each postprocess stream, including a one-line stream fixture.
- WebUI supports JSON file import, pasted JSON, and Download export with a textarea fallback.

## Hook activation state (v0.5.1)
- Installer now writes `mode=legacy_xml_staged` rather than claiming the hook is already installed before a reboot.
- `service.sh` performs a post-boot check against the active `/vendor`, `/odm`, `/system_ext`, or `/system` audio XML and ABI-matched library path, then records `legacy_xml_config_active` only when both are visible.
- Action reports configuration/library visibility separately from a runtime AudioFlinger signature. It does not fabricate a marker or restart `audioserver`.

## Still unverified
- Loading, SELinux access, latency, CPU load, and actual audible results on a real Android device.
- AIDL Audio Effects HAL is not implemented; installer deliberately skips it and reports `WEBUI ONLY`.
- Prebuilt native libraries are ARM/AArch64; non-ARM ABIs now stop before XML patching.
- Vendor may use non-standard XML, different effect namespace policy, or bypass AudioFlinger through direct/offload output.
- Audio configs from multiple concurrently active effects are shared by a polling worker; real device stress testing is still required.

## Intellectual property
DSP math and profile names are original. No Dolby or DTS proprietary libraries/algorithms are bundled; no certification or licensed-brand compatibility is claimed.
