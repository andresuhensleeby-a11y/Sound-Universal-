# Roadmap

- [x] WebUI liquid glass dengan latar Furina-style lokal.
- [x] Profil Music focus non-netral sebagai default dan migrasi konfigurasi v3 yang benar-benar netral.
- [x] Impor JSON lewat pemilihan file atau paste.
- [x] Ekspor JSON ke Download dengan fallback browser dan textarea.
- [x] Daftar fitur dan status integrasi ditampilkan saat instalasi / di WebUI.
- [ ] Uji playback nyata lintas vendor legacy/HIDL dan beragam format audio.
- [ ] Implementasi AIDL Audio Effects HAL sebagai service/factory tersendiri; ini bukan sekadar perubahan `audio_effects.xml`.
- [ ] Pengujian berulang Android 10–17, Snapdragon, MediaTek, AOSP, stock, dan port ROM sebelum menyebut dukungan universal.
