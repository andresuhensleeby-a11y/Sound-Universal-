#!/system/bin/sh
# Convert WebUI JSON settings into the key=value file polled by the native DSP.
MODPATH=${1:-${0%/*}/..}
STATE_DIR=/data/adb/sound_universal
SETTINGS="$STATE_DIR/settings.json"
DSP_DIR=/data/misc/audio
DSP_FILE="$DSP_DIR/sound_universal.conf"
mkdir -p "$STATE_DIR" 2>/dev/null || exit 1
chmod 0700 "$STATE_DIR" 2>/dev/null
[ -s "$SETTINGS" ] || cp "$MODPATH/config/default.json" "$SETTINGS" 2>/dev/null
[ -s "$SETTINGS" ] || exit 1

json_value() {
  # Extract the exact scalar key; supports both pretty and compact JSON without jq.
  VALUE=$(awk -v key="$1" '
    {
      pattern="\"" key "\"[[:space:]]*:[[:space:]]*"
      if (match($0, pattern)) {
        value=substr($0, RSTART+RLENGTH)
        sub(/[,}].*$/, "", value)
        gsub(/[[:space:]\"]/, "", value)
        print value
        exit
      }
    }
  ' "$SETTINGS" 2>/dev/null)
  [ -n "$VALUE" ] || VALUE="$2"
}
json_value schema_version 0
SCHEMA="$VALUE"
case "$SCHEMA" in ''|*[!0-9]*) SCHEMA=0;; esac
# Migrate very old UI-only schemas as before.
if [ "$SCHEMA" -lt 3 ]; then
  sed 's/"schema_version"[[:space:]]*:[[:space:]]*[0-9][0-9]*/"schema_version": 3/; s/"enabled"[[:space:]]*:[[:space:]]*false/"enabled": true/' "$SETTINGS" > "$SETTINGS.migrate" 2>/dev/null && mv "$SETTINGS.migrate" "$SETTINGS"
  SCHEMA=3
fi
# v4 used to have an all-zero Balanced default. Upgrade only that untouched neutral
# configuration to the Music focus preset; preserve any configuration with tuning.
if [ "$SCHEMA" -lt 4 ]; then
  json_value enabled true; MIG_ENABLED="$VALUE"
  json_value preset balanced; MIG_PRESET="$VALUE"
  ALL_ZERO=1
  for KEY in preamp bass clarity width compression eq0 eq1 eq2 eq3 eq4 eq5 eq6 eq7 eq8 eq9; do
    json_value "$KEY" 0
    case "$VALUE" in 0|0.0|0.00|0.000|-0|-0.0|-0.00|-0.000|'') ;; *) ALL_ZERO=0;; esac
  done
  case "$MIG_ENABLED:$MIG_PRESET:$ALL_ZERO" in
    true:balanced:1|1:balanced:1|on:balanced:1|true:neutral:1|1:neutral:1|on:neutral:1)
      cp "$MODPATH/config/default.json" "$SETTINGS.migrate" 2>/dev/null && mv "$SETTINGS.migrate" "$SETTINGS"
      ;;
    *)
      sed 's/"schema_version"[[:space:]]*:[[:space:]]*[0-9][0-9]*/"schema_version": 4/' "$SETTINGS" > "$SETTINGS.migrate" 2>/dev/null && mv "$SETTINGS.migrate" "$SETTINGS"
      ;;
  esac
fi

json_value enabled true
case "$VALUE" in true|1|on) ENABLED=1;; *) ENABLED=0;; esac
json_value preamp __MISSING__; [ "$VALUE" != "__MISSING__" ] || json_value preamp_db 0; PREAMP="$VALUE"
json_value bass __MISSING__; [ "$VALUE" != "__MISSING__" ] || json_value bass_db 0; BASS="$VALUE"
json_value clarity __MISSING__; [ "$VALUE" != "__MISSING__" ] || json_value clarity_db 0; CLARITY="$VALUE"
json_value width 0; WIDTH="$VALUE"
json_value compression 0; COMPRESSION="$VALUE"
mkdir -p "$DSP_DIR" 2>/dev/null || exit 1
{
  echo '# Sound universal - Rye / credit ryetechnologia'
  echo "enabled=$ENABLED"
  echo "preamp_db=$PREAMP"
  echo "bass_db=$BASS"
  echo "clarity_db=$CLARITY"
  echo "width=$WIDTH"
  echo "compression=$COMPRESSION"
  i=0
  while [ "$i" -lt 10 ]; do
    json_value "eq$i" 0
    echo "eq$i=$VALUE"
    i=$((i+1))
  done
} > "$DSP_FILE.tmp" 2>/dev/null || exit 1
chmod 0644 "$DSP_FILE.tmp" 2>/dev/null
if command -v restorecon >/dev/null 2>&1; then restorecon "$DSP_DIR" "$DSP_FILE.tmp" >/dev/null 2>&1; fi
mv "$DSP_FILE.tmp" "$DSP_FILE" 2>/dev/null || exit 1
chmod 0644 "$DSP_FILE" 2>/dev/null
if command -v restorecon >/dev/null 2>&1; then restorecon "$DSP_FILE" >/dev/null 2>&1; fi
exit 0
