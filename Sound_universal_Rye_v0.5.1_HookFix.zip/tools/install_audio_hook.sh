#!/system/bin/sh
# Stage a legacy/HIDL audio_effects.xml overlay. The Android audio stack reads this
# configuration during startup, so staging is not the same as runtime activation;
# service.sh verifies the merged active view after the next boot.
MODPATH=${1:-${0%/*}/..}
STATUS="$MODPATH/integration.status"
LIB64="$MODPATH/native_effect/build/libsounduniversal.so"
LIB32="$MODPATH/native_effect/build/libsounduniversal_arm.so"
rm -f "$STATUS"
if [ ! -s "$LIB64" ] && [ ! -s "$LIB32" ]; then
  echo 'mode=webui_only' > "$STATUS"
  echo 'reason=native audio effect library build missing' >> "$STATUS"
  exit 0
fi
ABI=$(getprop ro.product.cpu.abi 2>/dev/null | head -n 1)
[ -n "$ABI" ] || ABI=$(uname -m 2>/dev/null)
case "$ABI" in
  x86*|i?86|riscv*|riscv64*)
    echo 'mode=webui_only' > "$STATUS"
    echo "reason=prebuilt DSP libraries support ARM only; detected ABI: $ABI" >> "$STATUS"
    exit 0
    ;;
esac
# Stage ABI-correct libraries on vendor and system overlays. The config may be
# sourced from /vendor/etc, /odm/etc, /system_ext/etc, or /system/etc depending on ROM.
# These are systemless module files; the real system partition is never edited directly.
stage_library() {
  SOURCE="$1"
  ABI_DIR="$2"
  for PART in vendor system system_ext; do
    TARGET="$MODPATH/$PART/$ABI_DIR/soundfx/libsounduniversal.so"
    mkdir -p "${TARGET%/*}" 2>/dev/null || continue
    cp "$SOURCE" "$TARGET" 2>/dev/null || continue
    chmod 0644 "$TARGET" 2>/dev/null
  done
}
STAGED=0
if [ -s "$LIB64" ]; then
  stage_library "$LIB64" "lib64"
  [ ! -s "$MODPATH/vendor/lib64/soundfx/libsounduniversal.so" ] || STAGED=1
fi
if [ -s "$LIB32" ]; then
  stage_library "$LIB32" "lib"
  [ ! -s "$MODPATH/vendor/lib/soundfx/libsounduniversal.so" ] || STAGED=1
fi
if [ "$STAGED" -ne 1 ]; then
  echo 'mode=webui_only' > "$STATUS"
  echo 'reason=cannot stage native library in expected audio-effect search paths' >> "$STATUS"
  exit 0
fi
# If an AIDL effect factory is declared, do not patch the HIDL XML path.
for mf in /vendor/etc/vintf/manifest.xml /vendor/etc/vintf/manifest/*.xml /odm/etc/vintf/manifest.xml /odm/etc/vintf/manifest/*.xml /system/etc/vintf/manifest.xml /system/etc/vintf/manifest/*.xml; do
  [ -f "$mf" ] || continue
  if grep -q 'android.hardware.audio.effect' "$mf" 2>/dev/null && grep -q 'format="aidl"' "$mf" 2>/dev/null; then
    # Verify the format belongs to an audio effect HAL block in this file.
    if awk '
      /<hal[ >]/ { in_hal=1; aidl=($0 ~ /format="aidl"/) }
      in_hal && /format="aidl"/ { aidl=1 }
      in_hal && /<name>android\.hardware\.audio\.effect<\/name>/ && aidl { found=1 }
      in_hal && /<\/hal>/ { in_hal=0; aidl=0 }
      END { exit(found?0:1) }' "$mf"; then
      echo 'mode=webui_only' > "$STATUS"
      echo 'reason=AIDL Audio Effects HAL detected; legacy XML hook intentionally skipped' >> "$STATUS"
      exit 0
    fi
  fi
done
CANDIDATE=''
for p in /vendor/etc/audio_effects.xml /odm/etc/audio_effects.xml /system_ext/etc/audio_effects.xml /system/etc/audio_effects.xml; do
  if [ -s "$p" ] && grep -q '<audio_effects_conf' "$p" 2>/dev/null; then CANDIDATE="$p"; break; fi
done
if [ -z "$CANDIDATE" ]; then
  echo 'mode=webui_only' > "$STATUS"
  echo 'reason=no supported legacy audio_effects.xml was found' >> "$STATUS"
  exit 0
fi
REL=${CANDIDATE#/}
DEST="$MODPATH/$REL"
TMP="$DEST.sounduniversal.tmp"
mkdir -p "${DEST%/*}" 2>/dev/null
if ! awk -f "$MODPATH/tools/patch_audio_effects.awk" "$CANDIDATE" > "$TMP" 2>/dev/null; then
  rm -f "$TMP"
  echo 'mode=webui_only' > "$STATUS"
  echo "reason=XML did not match expected legacy layout: $CANDIDATE" >> "$STATUS"
  exit 0
fi
if ! grep -q 'uuid="7e3522c1-9347-4c81-a23a-1a233a220001"' "$TMP" || ! grep -q '<postprocess' "$TMP"; then
  rm -f "$TMP"
  echo 'mode=webui_only' > "$STATUS"
  echo 'reason=XML integration validation failed' >> "$STATUS"
  exit 0
fi
mv "$TMP" "$DEST" || { rm -f "$TMP"; echo 'mode=webui_only' > "$STATUS"; echo 'reason=cannot stage patched XML' >> "$STATUS"; exit 0; }
chmod 0644 "$DEST" 2>/dev/null
# Do not claim that a hook is active at install time: systemless overlays are
# mounted on boot and the audio stack reads effect XML during service startup.
echo 'mode=legacy_xml_staged' > "$STATUS"
echo "config=$CANDIDATE" >> "$STATUS"
echo "uuid=7e3522c1-9347-4c81-a23a-1a233a220001" >> "$STATUS"
echo 'note=XML and library overlay staged; reboot is required before the audio stack can read this configuration.' >> "$STATUS"
exit 0
