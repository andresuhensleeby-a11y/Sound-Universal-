#!/system/bin/sh
MODDIR=${0%/*}/..
echo "Sound universal 🎧 v0.5.1"
echo "Creator: Rye | Credit: ryetechnologia"
echo "Integration record:"
cat "$MODDIR/integration.status" 2>/dev/null || echo "not created"
echo "DSP config file:"
cat /data/misc/audio/sound_universal.conf 2>/dev/null || echo "not readable from root shell"
