#!/system/bin/sh
# Runs after the module overlay has been mounted during boot. This verifies
# the active system view, not merely the copy staged inside the module folder.
MODPATH=${1:-${0%/*}/..}
STATUS="$MODPATH/integration.status"
UUID='7e3522c1-9347-4c81-a23a-1a233a220001'
OLD_MODE=$(sed -n 's/^mode=//p' "$STATUS" 2>/dev/null | head -n 1)
case "$OLD_MODE" in
  legacy_xml_staged|legacy_xml_hook_installed|legacy_xml_overlay_not_active|legacy_xml_config_active|legacy_xml_config_active_library_missing) ;;
  *) exit 0 ;;
esac

ACTIVE_CONFIG=''
for p in /vendor/etc/audio_effects.xml /odm/etc/audio_effects.xml /system_ext/etc/audio_effects.xml /system/etc/audio_effects.xml; do
  if [ -r "$p" ] && grep -q "$UUID" "$p" 2>/dev/null; then
    ACTIVE_CONFIG="$p"
    break
  fi
done

ACTIVE_LIB=''
ABI_LIST=$(getprop ro.product.cpu.abilist 2>/dev/null)
ABI=$(getprop ro.product.cpu.abi 2>/dev/null)
case " $ABI_LIST $ABI " in
  *arm64-v8a*)
    for p in /vendor/lib64/soundfx/libsounduniversal.so /odm/lib64/soundfx/libsounduniversal.so /system_ext/lib64/soundfx/libsounduniversal.so /system/lib64/soundfx/libsounduniversal.so; do
      if [ -s "$p" ]; then ACTIVE_LIB="$p"; break; fi
    done
    ;;
esac
if [ -z "$ACTIVE_LIB" ]; then
  case " $ABI_LIST $ABI " in
    *armeabi-v7a*|*armeabi*)
      for p in /vendor/lib/soundfx/libsounduniversal.so /odm/lib/soundfx/libsounduniversal.so /system_ext/lib/soundfx/libsounduniversal.so /system/lib/soundfx/libsounduniversal.so; do
        if [ -s "$p" ]; then ACTIVE_LIB="$p"; break; fi
      done
      ;;
  esac
fi

TMP="$STATUS.tmp.$$"
if [ -n "$ACTIVE_CONFIG" ] && [ -n "$ACTIVE_LIB" ]; then
  {
    echo 'mode=legacy_xml_config_active'
    echo "config=$ACTIVE_CONFIG"
    echo "library=$ACTIVE_LIB"
    echo "checked_at=$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null)"
    echo 'note=Active XML and ABI-matched library are visible after boot; actual playback processing still requires runtime testing.'
  } > "$TMP"
elif [ -n "$ACTIVE_CONFIG" ]; then
  {
    echo 'mode=legacy_xml_config_active_library_missing'
    echo "config=$ACTIVE_CONFIG"
    echo 'reason=The active XML contains the Sound universal UUID but the matching soundfx library was not found in standard active paths.'
    echo "checked_at=$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null)"
  } > "$TMP"
else
  {
    echo 'mode=legacy_xml_overlay_not_active'
    echo 'reason=The module overlay was staged but the active audio_effects.xml does not contain the Sound universal UUID after boot.'
    echo "staged_config=$(sed -n 's/^config=//p' "$STATUS" 2>/dev/null | head -n 1)"
    echo "checked_at=$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null)"
    echo 'note=Check that the module is enabled and the root manager mounted module overlays before audioserver started.'
  } > "$TMP"
fi
if [ -s "$TMP" ]; then
  chmod 0644 "$TMP" 2>/dev/null
  mv "$TMP" "$STATUS" 2>/dev/null || rm -f "$TMP"
else
  rm -f "$TMP"
fi
exit 0
