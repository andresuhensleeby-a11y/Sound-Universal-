# Systemlessly register Sound universal in a legacy audio_effects.xml.
# Existing streams are edited inside their own <stream>, including single-line XML.
function clean_comments(s, out, i, p, rest) {
  out=""; i=1
  while (i <= length(s)) {
    rest=substr(s,i)
    if (in_comment) {
      p=index(rest,"-->")
      if (!p) break
      i=i+p+2
      in_comment=0
    } else {
      p=index(rest,"<!--")
      if (!p) { out=out rest; break }
      out=out substr(rest,1,p-1)
      i=i+p+3
      in_comment=1
    }
  }
  return out
}
function stream_type(s, t) {
  if (match(s, /<stream[^>]*type[[:space:]]*=[[:space:]]*"[a-z_]+"/)) {
    t=substr(s,RSTART,RLENGTH)
    sub(/^.*type[[:space:]]*=[[:space:]]*"/,"",t)
    sub(/".*$/,"",t)
    return t
  }
  return ""
}
{
  lines[NR]=$0
  active[NR]=clean_comments($0)
  x=active[NR]
  if (x ~ /<libraries([[:space:]>])/) has_libraries=1
  if (x ~ /<\/libraries>/) has_libraries_close=1
  if (x ~ /<effects([[:space:]>])/) has_effects=1
  if (x ~ /<postprocess([[:space:]>])/) has_post=1
  if (x ~ /<\/effects>/) has_effects_close=1
  if (x ~ /<\/audio_effects_conf>/) has_root_close=1
  if (x ~ /<library[^>]*name="sound_universal"/) has_library=1
  if (x ~ /<effect[^>]*name="sound_universal"/) has_effect=1
  if (x ~ /<postprocess([[:space:]>])/) in_post_first=1
  t=stream_type(x)
  if (in_post_first && t!="") {
    has_stream[t]=1
    current_first=t
    if (x ~ /<apply[^>]*effect="sound_universal"/) has_apply[t]=1
    # Handle an entire stream on one line.
    if (x ~ /<\/stream>/) current_first=""
  } else if (in_post_first && current_first!="" && x ~ /<apply[^>]*effect="sound_universal"/) {
    has_apply[current_first]=1
  }
  if (in_post_first && x ~ /<\/stream>/) current_first=""
  if (x ~ /<\/postprocess>/) { in_post_first=0; current_first="" }
}
END {
  if (!has_libraries || !has_libraries_close || !has_effects || !has_effects_close || !has_root_close) exit 12
  ntypes=4; types[1]="music"; types[2]="ring"; types[3]="alarm"; types[4]="notification"
  in_post=0; current=""
  for (i=1;i<=NR;i++) {
    x=active[i]; out=lines[i]
    if (x ~ /<\/libraries>/ && !has_library) print "  <library name=\"sound_universal\" path=\"libsounduniversal.so\"/>"
    if (x ~ /<\/effects>/ && !has_effect) print "  <effect name=\"sound_universal\" library=\"sound_universal\" uuid=\"7e3522c1-9347-4c81-a23a-1a233a220001\"/>"

    if (!has_post && x ~ /<\/audio_effects_conf>/) {
      print "  <postprocess>"
      print "    <stream type=\"music\"><apply effect=\"sound_universal\"/></stream>"
      print "    <stream type=\"ring\"><apply effect=\"sound_universal\"/></stream>"
      print "    <stream type=\"alarm\"><apply effect=\"sound_universal\"/></stream>"
      print "    <stream type=\"notification\"><apply effect=\"sound_universal\"/></stream>"
      print "  </postprocess>"
    }

    if (x ~ /<postprocess([[:space:]>])/) in_post=1
    if (in_post) {
      t=stream_type(x)
      if (t!="") current=t

      if (x ~ /<\/stream>/ && current!="" && (current=="music"||current=="ring"||current=="alarm"||current=="notification") && !has_apply[current]) {
        # Insert within the current stream; works for one-line and multiline XML.
        sub(/<\/stream>/,"<apply effect=\"sound_universal\"/></stream>",out)
        has_apply[current]=1
      }

      if (x ~ /<\/postprocess>/) {
        extra=""
        for (j=1;j<=ntypes;j++) if (!has_stream[types[j]]) {
          extra=extra "\n    <stream type=\"" types[j] "\"><apply effect=\"sound_universal\"/></stream>"
          has_stream[types[j]]=1
          has_apply[types[j]]=1
        }
        sub(/<\/postprocess>/,extra "\n  </postprocess>",out)
      }
    }

    print out
    if (x ~ /<\/stream>/) current=""
    if (x ~ /<\/postprocess>/) { in_post=0; current="" }
  }
}
